from django.urls import path
from . import views
from .views import contact_view
from django.views.generic import TemplateView


urlpatterns = [
    path('', views.index, name="home"),
    path("result", views.result, name="result"),
    path('contact/', views.contact_view, name='contact'),
    path('success/', TemplateView.as_view(template_name='success.html'), name='success'),
]
